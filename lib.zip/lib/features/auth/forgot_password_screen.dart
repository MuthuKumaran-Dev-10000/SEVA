import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme.dart';
import '../../core/services/auth_provider.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _answerController = TextEditingController();
  final _newPassController = TextEditingController();
  
  bool _emailVerified = false;
  String _detectedQuestion = '';
  bool _isSearching = false;

  @override
  void dispose() {
    _emailController.dispose();
    _answerController.dispose();
    _newPassController.dispose();
    super.dispose();
  }

  void _verifyEmail() async {
    if (_emailController.text.isEmpty || !_emailController.text.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid email address.')),
      );
      return;
    }

    setState(() {
      _isSearching = true;
    });

    final auth = Provider.of<AuthProvider>(context, listen: false);
    final email = _emailController.text.trim();
    try {
      final question = await auth.firebaseService.getSecurityQuestion(email);

      if (question != null) {
        setState(() {
          _detectedQuestion = question;
          _emailVerified = true;
        });
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Account not found with this email.')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSearching = false;
        });
      }
    }
  }

  void _resetPassword() async {
    if (!_formKey.currentState!.validate()) return;

    final auth = Provider.of<AuthProvider>(context, listen: false);
    final success = await auth.resetPassword(
      email: _emailController.text.trim(),
      securityAnswer: _answerController.text.trim(),
      newPassword: _newPassController.text.trim(),
    );

    if (success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Password updated successfully! Log in now.'), backgroundColor: Colors.green),
      );
      Navigator.of(context).pop();
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(auth.errorMessage ?? 'Password reset failed.'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reset Password'),
        backgroundColor: DivineTheme.maroon,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Forgot Password',
              style: Theme.of(context).textTheme.displayMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            const Text(
              'Verify your registered email and answer your security question.',
              style: TextStyle(color: DivineTheme.textLight, fontSize: 13),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            if (!_emailVerified) ...[
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(
                  labelText: 'Email Address',
                  prefixIcon: Icon(Icons.email, color: DivineTheme.maroon),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 24),
              _isSearching
                  ? const Center(child: CircularProgressIndicator(color: DivineTheme.maroon))
                  : ElevatedButton(
                      onPressed: _verifyEmail,
                      child: const Text('VERIFY EMAIL'),
                    ),
            ] else ...[
              Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: DivineTheme.creamDark,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: DivineTheme.gold.withOpacity(0.5)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Security Question:',
                            style: TextStyle(fontWeight: FontWeight.bold, color: DivineTheme.maroon, fontSize: 12),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _detectedQuestion,
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _answerController,
                      decoration: const InputDecoration(
                        labelText: 'Your Answer',
                        prefixIcon: Icon(Icons.security, color: DivineTheme.maroon),
                      ),
                      validator: (v) => v == null || v.isEmpty ? 'Enter your answer' : null,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _newPassController,
                      decoration: const InputDecoration(
                        labelText: 'New Password',
                        prefixIcon: Icon(Icons.lock, color: DivineTheme.maroon),
                      ),
                      obscureText: true,
                      validator: (v) => v == null || v.length < 6 ? 'Must be at least 6 characters' : null,
                    ),
                    const SizedBox(height: 32),
                    Consumer<AuthProvider>(
                      builder: (context, auth, _) {
                        return auth.isLoading
                            ? const Center(child: CircularProgressIndicator(color: DivineTheme.maroon))
                            : ElevatedButton(
                                onPressed: _resetPassword,
                                style: ElevatedButton.styleFrom(backgroundColor: DivineTheme.saffron),
                                child: const Text('RESET PASSWORD'),
                              );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
